<?php
// Ambil dari variabel isi
if( $isi )
{
	$this->load->view($isi);
}